

On the shell server enter these commands  

To compile mut.c:

$ gcc mut.c -lpthread

To run:
$ ./a.out 

To compile .c

$ gcc mutno.c -lpthread

To run:

$ ./a.out